package com.mpinfo.markburguer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarkburguerApplicationTests {

	@Test
	void contextLoads() {
	}

}
