package com.mpinfo.markburguer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarkburguerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarkburguerApplication.class, args);
	}

}
